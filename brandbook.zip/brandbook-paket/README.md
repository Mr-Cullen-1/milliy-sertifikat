# Milliy sertifikat (Matematika) — brandbook paketi

Android ilovasi va app dasturchisi uchun brend, dizayn aktivlari va tayanch hujjatlar. Hammasi loyiha omboridan (`brandbook-android` branchi) yig‘ilgan.

## Tarkib

| Papka / fayl | Nima |
|---|---|
| `brandbook/` | Asosiy brandbook: `brandbook.md` (shriftlar, ranglar, o‘lchamlar, komponentlar, ikonkalar, holatlar), 10 ta ko‘rgazmali sahifa (`assets/*.png|svg`), tayyor tokenlar (`tokens/`: `tokens.json`, `colors.xml`, `dimens.xml`, `Color.kt`, `Type.kt`), shriftlar (`fonts/`: Nunito, Onest + OFL litsenziyalari), qayta yaratish skriptlari (`build.cjs`, `render.cjs`, `tokens.cjs`). Ichki `README.md` batafsil yo‘riqnoma beradi. |
| `design-assets/mascot-art/` | Ilovada ishlatiladigan tayyor rasmlar: maskot pozalari (`mascot-*.png`), 3D shakllar va bezaklar (`cube`, `orb`, `pyramid`, `crown`, `trophy`, …) hamda `icons/` ichidagi 8 ta SVG ikonka. |
| `design-assets/junior_trainer_assets/` | Manba aktivlar to‘plami (43 ta PNG + o‘z `README.txt` si): maskotlar, yulduzlar, bulutlar, raqamlar, shakllar, ikonkalar. Bitta kollajdan qirqilgan, fon oq (shaffof emas) va chetlarida ortiqcha piksellar bo‘lishi mumkin: ishlatishdan oldin ko‘rib chiqing. |
| `design-assets/junior_trainer_modal_assets/` | Modal/natija oynalari uchun manba aktivlar (24 ta PNG + 8 ta SVG + `README.txt`): to‘g‘ri/xato javob panellari, tanga, mukofot, ikonkalar. SVG ikonkalarni to‘g‘ridan-to‘g‘ri ishlating; PNG rasmlar ko‘rgazma uchun, ishlatishdan oldin qirqish/retush kerak bo‘lishi mumkin. |
| `design-assets/favicon.ico` | Sayt ikonkasi. |
| `references/design.md` | Dizayn manbasi (Figma), freymlar ID lari va olingan tokenlar jadvali. |
| `references/globals.css` | Veb-ilovadagi CSS tokenlar (ranglar, modal va mobil panel stillari). |
| `references/components-ui/` | Asosiy UI komponentlari: `button.tsx`, `chip.tsx`, `icons.tsx` (tugma, chip va ikonkalar qanday chizilishiga namuna). |
| `references/app-dasturchi-texnik-topshiriq.md` | App dasturchisi uchun texnik topshiriq (TT-01…TT-17, 7.1-bo‘lim: original aniq qoidalari). |
| `references/app-milliy-sertifikat-taqqoslash.md` | Appni original bilan taqqoslash hujjati (kamchiliklar, ekranlar xaritasi, qabul checklisti). |

## Muhim ranglar

Asosiy `#E8590C`, aksent `#4B2FD0`, sahifa foni `#F3F1FB`, matn `#1E1B39`. To‘liq jadval: `references/design.md` va `brandbook/brandbook.md`.

## Eslatmalar

- `brandbook/assets/*.svg` shriftni `../fonts/` dan oladi: `assets/` va `fonts/` papkalarini yonma-yon saqlang.
- `references/` ichidagi ikki hujjat loyiha omboridagi fayllarga (`../lib/…`, `../content/…`, `../config/…`) havola qiladi. Bu havolalar paket ichida ishlamaydi; manba kodi alohida beriladi.
- Figma maketi (17 ekran, Android): https://www.figma.com/design/EgMX8rtOFvqG3RbUiL3aKO
- Veb-platformaning dizayn manbasi: https://www.figma.com/design/B35bKfnkHAPkxG8OUEX4S4
- Shriftlar SIL Open Font License ostida (`brandbook/fonts/OFL-*.txt`).
